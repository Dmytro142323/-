# -
Here you can translate everything into different languages ​​such as English, Ukrainian, Polish, German, French and Spanish.
