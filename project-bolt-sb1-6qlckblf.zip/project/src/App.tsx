import React, { useState } from 'react';
import { Languages, ArrowRightLeft } from 'lucide-react';

function App() {
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const [fromLang, setFromLang] = useState('en');
  const [toLang, setToLang] = useState('uk');
  const [isLoading, setIsLoading] = useState(false);

  const languages = [
    { code: 'en', name: 'English' },
    { code: 'uk', name: 'Ukrainian' },
    { code: 'pl', name: 'Polish' },
    { code: 'de', name: 'German' },
    { code: 'fr', name: 'French' },
    { code: 'es', name: 'Spanish' },
  ];

  const handleTranslate = async () => {
    if (!inputText) return;
    
    setIsLoading(true);
    try {
      const response = await fetch(
        `https://api.mymemory.translated.net/get?q=${encodeURIComponent(
          inputText
        )}&langpair=${fromLang}|${toLang}`
      );
      const data = await response.json();
      setOutputText(data.responseData.translatedText);
    } catch (error) {
      console.error('Translation error:', error);
      setOutputText('Translation error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const switchLanguages = () => {
    setFromLang(toLang);
    setToLang(fromLang);
    setInputText(outputText);
    setOutputText(inputText);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 to-blue-100 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center gap-3 mb-6">
            <Languages className="w-8 h-8 text-purple-600" />
            <h1 className="text-2xl font-bold text-gray-800">Universal Translator</h1>
          </div>

          <div className="flex gap-4 mb-6">
            <select
              value={fromLang}
              onChange={(e) => setFromLang(e.target.value)}
              className="block w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              {languages.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.name}
                </option>
              ))}
            </select>

            <button
              onClick={switchLanguages}
              className="p-2 text-purple-600 hover:bg-purple-100 rounded-full transition-colors"
            >
              <ArrowRightLeft className="w-6 h-6" />
            </button>

            <select
              value={toLang}
              onChange={(e) => setToLang(e.target.value)}
              className="block w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              {languages.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.name}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Enter text to translate..."
                className="w-full h-40 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
              />
            </div>
            <div>
              <textarea
                value={outputText}
                readOnly
                placeholder="Translation will appear here..."
                className="w-full h-40 p-3 bg-gray-50 border border-gray-300 rounded-lg resize-none"
              />
            </div>
          </div>

          <button
            onClick={handleTranslate}
            disabled={isLoading || !inputText}
            className="mt-4 w-full bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition-colors disabled:bg-purple-300"
          >
            {isLoading ? 'Translating...' : 'Translate'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;